package name.panitz.game2d.kasetenrekorder;

import java.awt.*;
import java.util.List;

import name.panitz.game2d.*;
import org.w3c.dom.Text;
import org.w3c.dom.ls.LSOutput;

import javax.swing.*;
import java.util.ArrayList;
import java.awt.event.*;
import java.util.Objects;

import static java.awt.event.KeyEvent.*;

// TODO: Random Gegner Bewegungen: Es sollen mit der Zeit immer mehr Gegner gespawnt werden.
// TODO: Optional: Items
// TODO: Optional: Startbildschirm
// TODO: Optional: High Score

final class Main implements Game {
    private final ImageObject player;
    private final List<List<? extends GameObj>> goss;
    private final int width;
    private final int height;
    private final int[] lieferungen;
    private final List<GameObj> hintergrund;
    private final List<GameObj> gegner;
    private final List<GameObj> wolken;
    private final List<GameObj> texte;
    private final List<GameObj> ziel;

    private final List<GameObj> ende;
    private int timer;
    private final List<GameObj> eingang;
    int x = 2400;


    Main(ImageObject player, List<List<? extends GameObj>> goss
            , int width, int height, int[] lieferungen
            , List<GameObj> hintergrund, List<GameObj> gegner
            , List<GameObj> wolken, List<GameObj> texte
            , List<GameObj> ziel, int timer, List<GameObj> ende
            , List<GameObj> eingang) {
        this.player = player;
        this.goss = goss;
        this.width = width;
        this.height = height;
        this.lieferungen = lieferungen;
        this.hintergrund = hintergrund;
        this.gegner = gegner;
        this.wolken = wolken;
        this.texte = texte;
        this.ziel = ziel;
        this.timer = timer;
        this.ende = ende;
        this.eingang = eingang;
    }


    Main() {
        this(new ImageObject(new Vertex(200, 200), new Vertex(1, 1), "fahrradkurier-schnell.gif")
                , new ArrayList<>(), 1920, 768, new int[]{0}
                , new ArrayList<>(), new ArrayList<>()
                , new ArrayList<>(), new ArrayList<>()
                , new ArrayList<>(), (int) (120 * SwingScreen.umwandlung)
                , new ArrayList<>(), new ArrayList<>());
    }


    public void init() {
        goss().clear();
        goss().add(hintergrund());
        goss().add(gegner());
        goss().add(wolken());
        goss().add(texte());
        goss().add(ziel());
        goss().add(ende);
        goss().add(eingang);
        hintergrund().clear();
        gegner().clear();
        wolken().clear();
        texte().clear();
        texte().add(new TextObject(new Vertex(10, 30), "Lieferungen: " + 0));
        texte().add(new TextObject(new Vertex(10, 60), "Timer: " + 0));
        ziel().clear();
        this.timer = (int) (121 * SwingScreen.umwandlung);
        this.lieferungen[0] = 0;
        player().velocity().x = 0;
        player().velocity().y = 0;
        player().pos().x = 0;
        player().pos().y = this.height() / 2D - player().height() / 2D;


        hintergrund().add(new ImageObject("straße.png"));


        /*wolken().add(new ImageObject(
                new Vertex(800, 10), new Vertex(-1, 0), "wolke.png"));*/

        gegner().add(new ImageObject(
                new Vertex(width() - 134 - 35, height()/2D - 60), new Vertex(-1.5, 0), "kunde.png"));

        ziel().add(new ImageObject(
                new Vertex(this.width() - 134, this.height() / 2D - 236 -30), new Vertex(0, 0), "restaurant.png"));

        eingang().add(new ImageObject(
                new Vertex(0, this.height() / 2D -30), new Vertex(0, 0), "startbereich.png"));

        ((TextObject) texte().get(0)).text = "Lieferungen: 0";
    }


    public void doChecks() {

        /*for (var w : wolken()) {
            if (w.isLeftOf(0)) {
                w.pos().x = width();

            }
        }*/


        for (var z : gegner()) {

            if (z.isLeftOf(0) || z.touches(eingang().get(0))) {
                z.pos().x = width() - ziel().get(0).width() - gegner().get(0).width();
                z.pos().y = height()/2D - 60;
            }



            if (player.touches(z)) {
                z.pos().moveTo(new Vertex(width() + 10, z.pos().y));
                timer = 0;
            }


            //Die Kunden sollen beim Taumeln nicht aus dem Spielfeld taumeln können
            if (z.isAbove(42) && z.velocity().y <= -1) z.velocity().y = 0;
            if (z.isAbove(42)) z.pos().y = 0;

            if (z.isUnderneath(this.height - z.height()) && z.velocity().y >= 1)
                z.velocity().y = 0;
            if (z.isUnderneath(this.height - z.height()))
                z.pos().y = this.height - z.height();

            //Die Kunden sollen nicht gegen den Spieler laufen, solange sich dieser im Eingangsbereich befindet
            //if (z.touches(eingang().get(0)) && z.pos().x <= eingang().get(0).width()) {z.velocity().x = 0; System.out.println("Vorne");}

        }

        //Es soll alle x Sekunden ein Gegner generiert werden.
        if(timer%x == 0 && timer>0){
            gegner().add(new ImageObject(new Vertex(width() - 134 - 35, height()/2D - 60), new Vertex(-1.5, 0), "kunde.png"));
            System.out.println("Kunden: " + gegner().size());
        }

        //Die Kunden haben eine Lebensmittelvergiftung und sollen durch die Gegend taumeln.
        for (var z: gegner()) {
            if (timer % 20 == 0 && !z.touches(eingang().get(0))) {
                z.velocity().y = ((Math.random() > 0.5 ? 1 : -1)) * (int) ((Math.random() * 10) / 3);
            }
        }

        //Der Spieler soll daran gehindert werden, das Spielfeld zu verlassen.
        //1. Test: Wenn er am Rand angekommen ist, wird seine Geschwindigkeit in die Richtung 0 gesetzt, damit er da nicht mehr hin kann
        //2. Test: Falls er versucht, weiter nach oben zu drücken, wird seine Position zurückgesetzt
        if (player().isAbove(42) && player().velocity().y <= -1) player().velocity().y = 0;
        if (player().isAbove(42)) player().pos().y = 0;

        if (player().isUnderneath(this.height - player().height()) && player().velocity().y >= 1)
            player().velocity().y = 0;
        if (player().isUnderneath(this.height - player().height()))
            player().pos().y = this.height - player.height();

        if (player().isLeftOf(90) && player().velocity().x <= -1) player().velocity().x = 0;
        if (player().isLeftOf(90)) player().pos().x = 0;

        if (player().isRightOf(this.width - player().width()) && player().velocity().x >= 1)
            player().velocity().x = 0;
        if (player().isRightOf(this.width - player().width())) player().pos().x = this.width - player.width();

        // Timer
        ((TextObject) texte().get(1)).text = "Zeit: " + (int) (timer / SwingScreen.umwandlung);
        if (timer > 0) {
            timer--;
        }

        //Aktionen beim Berühren vom Ziel: Zurückgesetzt werden
        if (player().touches(ziel().get(0))) {
            player().pos().x = 0;
            player().pos().y = this.height() / 2D - player().height() / 2D;
            player().velocity().x = 0;
            player().velocity().y = 0;
            lieferungen[0]++;
            ((TextObject) texte().get(0)).text = "Lieferungen: " + lieferungen[0];
        }

        //Je nach Gang soll das Bild bzw. die Animation des Spielers anders aussehen:
        if (player().velocity().x == 0) player().setImage("fahrradkurier.png");
        if (player().velocity().x == 3) player().setImage("fahrradkurier.gif");
        if (player().velocity().x == 6) player().setImage("fahrradkurier-schnell.gif");

        //Wenn man steht, sollte man nicht weiter nach oben oder unten fahren. Daher muss man dann angehalten werden.
        if (player().velocity().x == 0 && player().velocity().y != 0) player().velocity().y = 0;
        //Außerdem soll man zurückgefahren werden, wenn man an der Que Mara vorbei fährt.
        if (player().pos().x == width - player().width() && player().pos().x != width - player().width() - ziel().get(0).width()) {
                player().velocity().x = -1;
                player().velocity().y = 0;
        }
        if(player().pos().x == width - player().width() - ziel().get(0).width()) player().velocity().x = 0;
    }

    //Game Over Screen
    @Override
    public void paintTo(Graphics g) {
        for (var gos : goss()) gos.forEach(go -> go.paintTo(g));
        player().paintTo(g);
        if (timer == 0) {
            g.setColor(Color.black);
            g.fillRect(0, 0, width, height);
            g.setColor(Color.white);
            g.drawString("Game Over", width / 2 - 40, height / 2);
            g.drawString("Score: " + lieferungen[0], width / 2 - 25, height / 2 + 35);
            g.drawString("To restart, press Enter.", width / 2 - 80, height / 2 + 70);
        }
    }

    //Anhalten Spieler
    @Override
    public void move() {
        if (timer == 0) return;
        for (var gos : goss()) gos.forEach(go -> go.move());
        player().move();
    }

    public void keyPressedReaction(KeyEvent keyEvent) {
        switch (keyEvent.getKeyCode()) {
            case VK_RIGHT -> {
                if (player().velocity().x < 4) player().velocity().add(new Vertex(3, 0));
            }
            case VK_LEFT -> {
                if (player().velocity().x > 0) player().velocity().add(new Vertex(-3, 0));
            }
            case VK_DOWN -> {
                if(player().velocity().y < 4 && player().velocity().x != 0
                        && (!(player.velocity().x == -1))) {
                    player().velocity().add(new Vertex(0, 1));
                }
            }
            case VK_UP -> {
                if(player().velocity().y > -4 && player().velocity().x != 0
                        && (!(player.velocity().x == -1))) {
                    player().velocity().add(new Vertex(0, -1));
                }
            }
            /*case VK_Q -> {
                gegner().get(0).pos().x = width() - ziel().get(0).width() - gegner().get(0).width();
                gegner().get(0).pos().y = height()/2D - 60;
            }*/
            case VK_SPACE -> {
                if (timer == 0) init();
            }
        }
    }

    public void keyReleasedReaction(KeyEvent keyEvent){
        /*switch (keyEvent.getKeyCode()) {
            case VK_DOWN -> player().velocity().add(new Vertex(0, -player.velocity().y));
            case VK_UP -> player().velocity().add(new Vertex(0, player.velocity().y));
        }*/
    }

    @Override
    public boolean won() {
        return false;
    }

    @Override
    public boolean lost() {
        return false;
    }


    public static void main(String... args) {
        new Main().play();
    }

    @Override
    public ImageObject player() {
        return player;
    }

    @Override
    public List<List<? extends GameObj>> goss() {
        return goss;
    }

    @Override
    public int width() {
        return width;
    }

    @Override
    public int height() {
        return height;
    }

    public int[] schaden() {
        return lieferungen;
    }

    public List<GameObj> hintergrund() {
        return hintergrund;
    }

    public List<GameObj> gegner() {
        return gegner;
    }

    public List<GameObj> wolken() {
        return wolken;
    }

    public List<GameObj> texte() {
        return texte;
    }

    public List<GameObj> ziel() {
        return ziel;
    }

    public List<GameObj> eingang() {
        return eingang;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Main) obj;
        return Objects.equals(this.player, that.player) &&
                Objects.equals(this.goss, that.goss) &&
                this.width == that.width &&
                this.height == that.height &&
                Objects.equals(this.lieferungen, that.lieferungen) &&
                Objects.equals(this.hintergrund, that.hintergrund) &&
                Objects.equals(this.gegner, that.gegner) &&
                Objects.equals(this.wolken, that.wolken) &&
                Objects.equals(this.texte, that.texte) &&
                Objects.equals(this.ziel, that.ziel) &&
                this.timer == that.timer;
    }

    @Override
    public int hashCode() {
        return Objects.hash(player, goss, width, height, lieferungen, hintergrund, gegner, wolken, texte, ziel, timer);
    }

    @Override
    public String toString() {
        return "Main[" +
                "player=" + player + ", " +
                "goss=" + goss + ", " +
                "width=" + width + ", " +
                "height=" + height + ", " +
                "schaden=" + lieferungen + ", " +
                "hintergrund=" + hintergrund + ", " +
                "gegner=" + gegner + ", " +
                "wolken=" + wolken + ", " +
                "texte=" + texte + ", " +
                "ziel=" + ziel + ", " +
                "timer=" + timer + ']';
    }

}

